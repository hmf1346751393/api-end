import User from './test'




const user = {
    name:'wxq',
    age:'39',
    email:'1346751393@qq.com'

}
//z
   const saveMethods = async () => {
    const data = new User(user)
    const result = await data.save()
    console.log(result);
}
//c
const findMethods = async () => {
   
    const result = await User.find()
    console.log(result);
}

//up
const updateMethods = async () => {
   
    const result = await User.updateOne({name:'wxq'},{email:'wxx@qq.com'})
    console.log(result);
}
updateMethods()


//shan
const deleteMethods = async () => {
   
    const result = await User.deleteOne({name:'wxq'})
    console.log(result);
}


