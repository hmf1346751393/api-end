const DB_URL = 'mongodb://use:use@localhost:27017/cc'

const REDIS = {
    host: '127.0.0.1',
    port: 6379,
    password: 'Huang@996'
}

const JWT_SECRET = 'a&*38QthAKuiRwISGLotgq^3%^$zvA3A6Hfr8MF$jM*HY4*dWcwAW&9NGp7*b53!'

export default {
    DB_URL,
    REDIS,
    JWT_SECRET
}