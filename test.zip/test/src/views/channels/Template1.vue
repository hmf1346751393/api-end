<template>
    <div class="layui-container" >
        <div class="layui-col-md8">
          <list></list>
        </div>
        <div class="layui-col-md4">
          <tips></tips>
          <!-- <hotlist></hotlist>
          <ads></ads>
          <links></links> -->
        </div>
    </div>
    </template>
    
    <script>
        
  import Tips from '@/components/sidebar/Tips'
//   import Sign from '@/components/sidebar/Sign'
//   import Hotlist from '@/components/sidebar/HotList'
//   import Ads from '@/components/sidebar/Ads'
//   import Links from '@/components/sidebar/Links'
  import List from '@/components/contest/List'
    export default {
      name: 'Template',
      components:{
      Tips,
    //   Sign,
    //   Hotlist,
    //   Ads,
    //   Links,
      List
    }
    
    }
    </script>
    
    <!-- Add "scoped" attribute to limit CSS to this component only -->
    <style scoped lang="scss">
      .layui-container{
        display: table
      }
    </style>
    