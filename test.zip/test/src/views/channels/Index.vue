<template>
  <div class="aaaa">
    <div class="layui-container" >
        <div class="layui-col-md8">
          <top></top>
          <list></list>
        </div>
        <div class="layui-col-md3">
          <tips></tips>
          <sign></sign>
          <hotlist></hotlist>
          <ads></ads>
          <links></links>
        </div>
    </div>
  </div>
    </template>
    
    <script>
        
  import Tips from '@/components/sidebar/Tips'
  import Sign from '@/components/sidebar/Sign'
  import Hotlist from '@/components/sidebar/HotList'
  import Ads from '@/components/sidebar/Ads'
  import Links from '@/components/sidebar/Links'
  import List from '@/components/contest/List'
  import Top from '@/components/contest/Top'
    export default {
      name: 'index',
      components:{
      Tips,
      Sign,
      Hotlist,
      Ads,
      Links,
      List,
      Top
    }
    
    }
    </script>
    
    <!-- Add "scoped" attribute to limit CSS to this component only -->
    <style scoped lang="scss">
       .layui-container{
        display: table
      }
    .layui-col-md3{
      margin: 0 0px 0 20px
    }
    </style>
    