export default {
    baseUrl:{
        // dev: 'https://mock.mengxuegu.com/mock/61920bfff126df7bfd5b7935',
        dev: 'http://localhost:3000',
        pro:'http:www.toimc.com:12000'
    }
}