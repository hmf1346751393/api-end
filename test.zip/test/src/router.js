import Vue from 'vue'
import VueRouter from 'vue-router'
// import Home from './views/Home.vue'
const Home = () => import('./views/Home')
const Login = () => import('./views/Login')
const Reg = () => import('./views/Reg')
const Forget = () => import('./views/Forget')
const Index = () => import('./views/channels/Index')
const Template = () => import('./views/channels/Template1')
const test = () => import('./views/test')
const Listadd = () => import('./views/Listadd')
const Center = () => import('./views/Center')

Vue.use(VueRouter)

const routes = [
  // {
  //   path: '/',
  //   redirect: 'login',
  //   // component: Login
  // },
  {
    path: '/login',
    component: Login,
    name: 'login'
  },
  {
    path: '/',
    component: Home,
    children: [
      {
      path: '',
      component: Index,
      name: 'index',
    },
    {
      path: '/index/:catalog',
      component: Template,
      name: 'catalog',
    }
        ]
  },
  {
    path: '/reg',
    component: Reg,
    name: 'reg',
    beforeEnter: (to, from, next) =>{
      if(from.name === 'login'){
        next()
      }else{
        next('./login')
      }
      
    }
  },
  {
    path: '/forget',
    component: Forget,
    name :'forget'
  },
  {
    path: '/test',
    component: test,
    name :'test'
  },
  {
    path: '/add',
    component: Listadd,
    name :'listadd'
  },
  {
    path: '/center',
    component: Center,
    name :'center'
  }
]
const router = new VueRouter({
  routes,
  linkExactActiveClass: 'layui-this',
  mode: 'history'
})

export default router

// export default new Router({
//   routes: [
//     {
//       path: '/',
//       name: 'home',
//       component: Home
//     },
//     {
//       path: '/login',
//       name: 'login',
//       // route level code-splitting
//       // this generates a separate chunk (about.[hash].js) for this route
//       // which is lazy-loaded when the route is visited.
//       component: () => import(/* webpackChunkName: "about" */ './views/Login.vue')
//     }
//   ]
// })
