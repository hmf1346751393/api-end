<template>
  <div id="app">
    <Header></Header>
    <router-view/>
    <Footer></Footer>
  </div>
</template>
<script>

</script>
<script>
   import Header from '@/components/Header'
   import Footer from '@/components/Footer'
   
// import axios from 'axios'

export default {
  name: 'app',
  components: {
    Header,
    Footer
  },
  data () {
    return {
      
    }
  },
  mounted () {

    
  },
  methods: {
    
    },
}
</script>

<style lang="scss" >
   @import "assets/layui/css/layui.css";
   @import "assets/css/global.css";
   @import "assets/layui/css/modules/layer/default/layer.css"; 


/* #app {
  background: #f2f2f2;
}
.layui-container {
  background: #fff;
}
input {
  width: 190px;
}
.imooc-link {
  margin-left: 10px;
  &:hover {
    color: #009688;
  }
}

.svg {
  position: relative;
  top: -15px;
}
.error{
  color:red;
} */
.gray{
  color:#999;
}
</style>
