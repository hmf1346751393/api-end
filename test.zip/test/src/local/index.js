import { Validator } from 'vee-validate'

const dictionary = {
  'zh-CN': {
    messages: {
      required: field => '请输入' + field,
      email: () => '请输入正确的邮箱格式',
      min: () => '输入长度位4位的密码',
      length: () => '输入长度位4位的密码'
    },
    attributes: {
      username: '邮箱',
      password: '密码',
      name: '账号',
      code: '验证码',
      repassword:'相同的密码'
    }
  }
}

Validator.localize(dictionary)
