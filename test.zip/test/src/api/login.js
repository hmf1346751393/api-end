import axios from '@/utils/request'
const getCode =  (sid) =>{
      return  axios.get('/public/getCaptcha',{
          params:{
              sid: sid
          }
      })
}
const forget =  (option) =>{
        return axios.post('/forget',{
            ...option
        })
}
const login =  (logininfo) =>{
    return axios.post('/login/login',{
        ...logininfo
    })  
}
const reg =  (reginfo) =>{
    return axios.post('/login/reg',{
        ...reginfo
    })
}
export {getCode ,forget ,login, reg} 