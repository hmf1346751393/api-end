// import axios from '@/utils/request'
// const forget =  (option) =>{
//         return axios.post('/forget',{
//             ...option
//         })
// }
// const reg =  (logininfo) =>{
//     return axios.post('/login/reg',{
//         ...logininfo
//     })
// }
// export { reg } 