<template>
  <div class="footer">
    <div class="fly-footer">
      <p><a href="/" target="_blank">Imooc社区</a> 2017 &copy; <a href="/" target="_blank">layui.com 出品</a></p>
      <p>
        <a href="/jie/3147/" target="_blank">付费计划</a>
        <a href="/template/fly/" target="_blank">获取Imooc社区模版</a>
        <a href="/jie/2461/" target="_blank">微信公众号</a>
      </p>
    </div>
    
    <!-- <script src="../res/layui/layui.js"></script> 
    <script>
    layui.cache.page = '';
    layui.cache.user = {
      username: '游客'
      ,uid: -1
      ,avatar: '../res/images/avatar/00.jpg'
      ,experience: 83
      ,sex: '男'
    };
    layui.config({
      version: "3.0.0"
      ,base: '../res/mods/'  //这里实际使用时，建议改成绝对路径
    }).extend({
      fly: 'index'
    }).use('fly');
    </script>
     -->
    
  </div>
</template>

<script>
export default {
  name: 'Footer',

}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">

</style>
