<!--  -->
<template>
    <div class="fly-panel" v-show="lists.length > 0">
        <div class="fly-panel-title fly-filter">
          <a>置顶</a>
          <!-- <a href="#signin" class="layui-hide-sm layui-show-xs-block fly-right" id="LAY_goSignin" style="color: #FF5722;">去签到</a> -->
          <a href="#signin" class="fly-right" id="LAY_goSignin" style="color: #FF5722;">去签到</a>
        </div>
        <list-item :lists="lists" :isShow="false" :isTop="true" ></list-item>
      </div>
</template>

<script>
  import ListItem from './ListItem'
export default {
    name: 'Top',
    components: {
      ListItem
 },data(){
   return{
    page: 0,
    limit: 20,
    lists:[
    {
      "isEnd": "0",
      "reads": 13,
      "answer": 2,
      "status": 0,
      "isTop": "0",
      "sort": "0",
      "_id": "5dc52692fae96d27f66fad40",
      "uid": {
        "name": "nakyd",
        "isVip": "0",
        "pic": "mock",
        "_id": "5dbe84e6e73b55bc5445d54c",
        "id": "5dbe84e6e73b55bc5445d54c"
      },
      "tags": [{
          name: '精华',
          class: 'layui-bg-red',
        },
        {
          name: '热门',
          class: 'layui-bg-blue',
        }

      ],
      "fav": "20",
      "title": "厚植企业创新创业的沃土（观象台）",
      "created": "2019-11-08 16:25:42",
      "catalog": "share",
      "content": "<p style=\"text-indent: 2em;\"> 未来的中国，需要擅长商业模式创新的企业，",
      "__v": 0,
      "id": "5dc52692fae96d27f66fad40"
    }
    ]
   }
 }
}

</script>
<style lang='scss' scoped>
</style>