<template>
  <div>
    <div class="fly-panel fly-link">
      <h3 class="fly-panel-title">友情链接</h3>
      <!-- <dl class="fly-panel-main">
        <dd><a href="/" target="_blank">layui</a><dd>
        <dd><a href="http://layim.layui.com/" target="_blank">WebIM</a><dd>
        <dd><a href="http://layer.layui.com/" target="_blank">layer</a><dd>
        <dd><a href="/laydate/" target="_blank">layDate</a><dd>
        <dd><a href="mailto:xianxin@layui-inc.com?subject=%E7%94%B3%E8%AF%B7Fly%E7%A4%BE%E5%8C%BA%E5%8F%8B%E9%93%BE" class="fly-link">申请友链</a><dd>
      </dl> -->
    </div>
  </div>
 
  </template>
  
  <script>
  export default {
    name: 'Links',
  
  }
  </script>
  
  <!-- Add "scoped" attribute to limit CSS to this component only -->
  <style scoped lang="scss">
  
  </style>
  