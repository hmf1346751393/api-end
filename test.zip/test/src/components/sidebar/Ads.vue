<template>
  <div class="fly-panel">
    <div class="fly-panel-title">
      这里可作为广告区域
    </div>
    <div class="fly-panel-main">
      <a href="http://layim.layui.com/?from=fly" target="_blank" class="fly-zanzhu" time-limit="2017.09.25-2099.01.01" style="background-color: #5FB878;">LayIM 3.0 - layui 旗舰之作</a>
    </div>
  </div>
  </template>
  
  <script>
  export default {
    name: 'Ads',
  
  }
  </script>
  
  <!-- Add "scoped" attribute to limit CSS to this component only -->
  <style scoped lang="scss">
  
  </style>
  